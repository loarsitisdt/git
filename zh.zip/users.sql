create table users
(
    id       int auto_increment
        primary key,
    username varchar(50)  not null,
    password varchar(255) not null,
    constraint username
        unique (username)
);

INSERT INTO zh.users (id, username, password) VALUES (1, 'zhanghao', '1234567');
INSERT INTO zh.users (id, username, password) VALUES (2, '王明轩', '123');
INSERT INTO zh.users (id, username, password) VALUES (5, 'zhang', '123456');
