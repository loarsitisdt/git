create table files
(
    file_name varchar(2000) null
);

INSERT INTO zh.files (file_name) VALUES ('20230530031523_64756a4b765ff.txt');
INSERT INTO zh.files (file_name) VALUES ('20230530031801_64756ae9eccc5.txt');
INSERT INTO zh.files (file_name) VALUES ('20230530031841_64756b1170534.txt');
INSERT INTO zh.files (file_name) VALUES ('20230530032130_64756bbad090c.txt');
