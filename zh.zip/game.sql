create table game
(
    name varchar(100)   not null,
    time date           not null,
    star float(2, 1)    not null,
    con  text           not null,
    num  decimal(10, 2) not null
);

INSERT INTO zh.game (name, time, star, con, num) VALUES ('GTA5', '2020-05-09', 5, '11111111111111111111111111111111111111111111111111111111111111111111', 1000.00);
INSERT INTO zh.game (name, time, star, con, num) VALUES ('元神', '2020-10-09', 2, '二次元冒险世界探险', 50.00);
